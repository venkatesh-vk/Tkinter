from tkinter import *
from PIL import Image,ImageTk
root=Tk()
root.title("Hello World")
root.iconbitmap("hi.ico")
root.geometry('400x400')
root.resizable(0,0)

rc="#440381"
ic="#51E5FF"
oc="#51E5FF"

root.config(bg=rc)

infr=LabelFrame(root,bg=ic)
oufr=LabelFrame(root,bg=oc)
infr.pack(pady=10)
oufr.pack(padx=10,pady=(0,10),fill=BOTH,expand=True)

def subf():
    if cs.get()==2:
        nl=Label(oufr,text=('Hello '+name.get()+" welcome to tkinter").upper(),bg=oc)
    else:
        nl=Label(oufr,text='Hello '+name.get()+" welcome to tkinter",bg=oc)
    name.delete(0,END)
    nl.pack()
name=Entry(infr,text="Enter your name",width=20)
subbtn=Button(infr,text='Submit',command=subf)
name.grid(row=0,column=0,padx=20,pady=10,ipadx=5,ipady=5)
subbtn.grid(row=0,column=1,padx=20,pady=10,ipadx=5,ipady=5)

cs=IntVar()
cs.set(1)
nrbtn=Radiobutton(infr,text="Normal case",variable=cs,value=1,bg=ic,activebackground=ic)
urbtn=Radiobutton(infr,text="Upper case",variable=cs,value=2,bg=ic,activebackground=ic)
nrbtn.grid(row=1,column=0,padx=5)
urbtn.grid(row=1,column=1)

sim=ImageTk.PhotoImage(Image.open('hi_1.png'))
siml=Label(oufr,image=sim,bg=oc)
siml.pack()

root.mainloop()